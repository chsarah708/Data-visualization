# Data dictionary

All data here is **synthetic**, generated for CDB601220 Week 3 from a fixed
seed, so every student works from identical files. The scenarios are illustrative; the failure modes they demonstrate are
not.

Every file has something wrong with it. This dictionary tells you what the
columns **mean**. It does not tell you what is wrong — that is the task.

---

## `vitals_10k.csv` — the primary dataset (Part D)

10,000 patient vital-sign records from the clinical safety review on slide 5.

| Column | Type | Unit | Meaning |
|---|---|---|---|
| `patient_id` | text | — | `P-00001` … `P-10000`, unique |
| `admit_date` | text | — | Date of admission, **as three source systems exported it** |
| `ward` | text | — | Admitting ward, as recorded at the bedside |
| `age` | int | years | 18–97 |
| `sex` | text | — | `F` / `M` |
| `systolic` | int | mmHg | Systolic blood pressure |
| `diastolic` | int | mmHg | Diastolic blood pressure |
| `map_mmhg` | float | mmHg | Mean arterial pressure. **Derived** — see the note below |
| `heart_rate` | int | bpm | Resting heart rate from the bedside monitor |
| `spo2` | int | % | Peripheral oxygen saturation. 100% is a physical ceiling |
| `bmi` | float | kg/m² | Body mass index |
| `chol_mmol_l` | float | mmol/L | Total cholesterol |
| `glucose_mmol_l` | float | mmol/L | Fasting plasma glucose |
| `los_days` | float | days | Length of stay |
| `readmitted_30d` | int | 0/1 | Readmitted within 30 days |
| `risk_score` | float | events/day | Adverse events per inpatient day |

**Two notes the file itself cannot give you:**

- `map_mmhg` is **computed** as `(systolic + 2 × diastolic) / 3`. It is the
  standard clinical formula. It is not a separate measurement, and its
  correlation with `systolic` is arithmetic. Slide 46.
- `risk_score` is a **ratio**. The mean of the column is not the overall rate.
  A rate is only correct at the level it was computed at; to aggregate it you
  need the numerator and the denominator, not the quotient.

---

## `ward_los_wide.csv` — length of stay, one column per ward

One column per ward, one length-of-stay value per cell, ragged (shorter wards
are padded with blanks).

Seaborn wants **long** data: one row per observation, one column per variable.
Pass this straight to `sns.boxplot` and you get an error or a chart of column
indices. `pandas.melt()` is the fix, and slide 33 is the slide.

---

## `case01_helmet_rickshaw.csv` — rider safety review

ShaheenGo delivery-rider safety review, Lahore, Feb–Jun 2026.
One row per rider.

| Column | Meaning |
|---|---|
| `rider_id` | `R-0001` …, unique |
| `helmet_grade` | `Standard` or `Premium` certification |
| `road_type` | `Motorway`, `City arterial`, `Inner-city lanes` |
| `trips` | Delivery trips completed in the period |
| `head_injuries` | Head injuries recorded |
| `avg_speed_kph` | Mean speed across the rider's trips |
| `months_experience` | Riding experience at the start of the period |

`avg_speed_kph` and `months_experience` describe the riders, not the helmets.
Any hypothesis you have about rider behaviour can be checked against them.

---

## `case02_chai_quizzes.csv` — canteen sales and quiz results

Campus canteen and examinations office, 24 months.
One row per month.

| Column | Meaning |
|---|---|
| `month` | `YYYY-MM` |
| `students_enrolled` | Head-count enrolled that month |
| `cups_doodh_patti_sold` | Cups sold at the canteen |
| `quiz_failures` | Quiz failures recorded |
| `is_exam_month` | 1 if an examination period fell in that month |
| `campus_open_days` | Teaching days in the month |

`is_exam_month` and `students_enrolled` are context columns. Neither appears
on the chart.

---

## `case03_aqi_monitors.csv` — the monitoring network

Punjab EPA network, Lahore, 120 days from 1 January 2026.
One row per station per day — **2,640 rows, not 2,640 measurements.**

| Column | Meaning |
|---|---|
| `date` | ISO date |
| `station_id` | `LHR-01` … `LHR-22` |
| `zone` | `Industrial`, `Arterial`, `Residential`, `Peri-urban` |
| `aqi` | Air Quality Index, or blank |
| `station_status` | `reporting` or `offline` |

A blank `aqi` means the station did not report that day. It is not a zero and
it is not an average. Note that `pandas.mean()` skips blanks without warning
you, so a mean over this column is a mean over whichever stations happened to
be reporting.

---

## `case04_quartet_depts.csv` — study hours and final scores

Registry extract, Semester 5. 11 students per department, 44 rows.

| Column | Meaning |
|---|---|
| `department` | Four departments |
| `cohort_group` | `I`–`IV`, the four intake groups |
| `study_hours_per_week` | Self-reported |
| `final_score_out_of_20` | Final examination mark |

Four departments, eleven students each. The hours are self-reported; the
scores come from the registry.

---

## `case05_same_stats_shapes.csv` — five learning-platform cohorts

Five cohorts of 180 students each.

| Column | Meaning |
|---|---|
| `shape_name` | The cohort label |
| `hours_on_platform` | Hours on the learning platform |
| `assessment_score` | Assessment score |

Every cohort reports mean 48.00 / 63.00, SD 12.00 / 15.00 and r = 0.420.

---

## `case06_sensor_matrix.csv` — the screening cohort

180 participants, 20 analysis variables plus three grouping columns.

| Column group | Columns |
|---|---|
| Blood pressure | `systolic`, `diastolic`, `map_mmhg` |
| Fitness | `resting_hr`, `vo2max` |
| Sleep | `sleep_hours`, `deep_sleep_min` |
| Activity | `step_count`, `floors_climbed` |
| Biochemistry | `hydration_index`, `cortisol_pm`, `hba1c`, `creatinine` |
| Demographics | `age_years`, `age_band` |
| Study design | `study_site`, `hr_device_model` |
| Instrument probes | `probe_a` … `probe_f` |

Units: `cortisol_pm` nmol/L · `creatinine` µmol/L · `hba1c` % ·
`vo2max` ml/kg/min · `resting_hr` bpm · `hydration_index` is a 0–100 index.

**`probe_a` … `probe_f` are unassigned instrument channels**, retained from
the raw sensor export. They are not calibrated against any physical quantity.
Real exports carry columns like these, and analysts correlate them anyway.

`study_site` and `hr_device_model` are study-design columns, not measurements.
Nothing stops you putting them on an axis.

---

## `case07_lie_factor.csv` — measured ink

Five published graphics, measured with a ruler.

| Column | Meaning |
|---|---|
| `chart_id` | `A`–`E`, matching the panels in the chart |
| `subject` | What the graphic is about |
| `value_start`, `value_end` | The two data values |
| `ink_start`, `ink_end` | The measured ink |
| `ink_unit` | What the ink measurement is in |
| `ink_dimension` | 1 if the quantity is encoded by a length, 2 if by an area |
| `how_the_graphic_encodes_it` | Prose description of the encoding |

`ink_dimension` is given to you here. In the wild you have to work it out, and
getting it wrong is exactly how a 1.5× icon reads as a 2.25× increase.

---

## `case07_dual_axis_series.csv` — monthly revenue and cost

| Column | Meaning |
|---|---|
| `month` | `Jan`–`Jun` |
| `revenue_pkr_m` | Monthly revenue, PKR millions |
| `cost_pkr_m` | Monthly cost, PKR millions |

Both columns are in the same unit: PKR millions.
